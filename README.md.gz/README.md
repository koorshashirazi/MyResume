# MyResume
.NET Developer with expertise in Azure DevOps

**Linkedin**
### https://www.linkedin.com/in/koorsha-shirazi/
